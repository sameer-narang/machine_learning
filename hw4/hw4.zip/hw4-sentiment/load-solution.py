import os
import numpy as np
import pickle
from math import log
import util as util
from collections import Counter
from nltk.corpus import stopwords
'''
Note: No obligation to use this code, though you may if you like.  Skeleton code is just a hint for people who are not familiar with text processing in python. 
It is not necessary to follow. 
'''

## Taken from http://web.stanford.edu/class/cs221/ Assignment #2 Support Code


class review_instance:
    """
    Build the review class
    """
    def __init__(self):
        self.word_list = []
        self.label = 0
        self.word_dict = Counter()
        self.word_tfidf = Counter()

    def set_label(self, label_val):
        self.label = label_val

    def read_file(self, file_name):
        '''
        Read each file into a list of strings. And set the list to self.word_list
        Example:
        ["it's", 'a', 'curious', 'thing', "i've", 'found', 'that', 'when', 'willis', 'is', 'not', 'called', 'on',
        ...'to', 'carry', 'the', 'whole', 'movie', "he's", 'much', 'better', 'and', 'so', 'is', 'the', 'movie']
        '''
        f = open(file_name)
        lines = f.read().split(' ')
        symbols = '${}()[].,:;+-*/&|<>=~" '
        words = map(lambda Element: Element.translate(None, symbols).strip(), lines)
        words = filter(None, words)
        self.word_list = words
        self.construct_word_dict(stop_word=stopwords.words('english'))

    def construct_word_dict(self, stop_word=None, count_words=None):
        """
        count the words in word_list, transform to a dict of (word: word_count)
        :param stop_word: a list of stop words, The words you hope to filter, not included in dict, default set to None
        :param count_words: a list, the words you hope to keep in the count_dict, if set to None, will keep all the words
        :return:
        """
        c = Counter()
        c = Counter(self.word_list)

        if count_words:
            c = Counter({i: c[i] for i in count_words})

        if stop_word:
            for i in stop_word:
                del c[i]

        self.word_dict = c
    
    def transform_to_tfidf(self, idf_dict):
        """
        Take a idf dict as input, constrcut the {word: tfidf} vector 
        tfidf = tf*(idf+1)
        """
        for word in self.word_dict:
            self.word_tfidf[word] = self.word_dict.get(word) * idf_dict.get(word, 1)
        


class corpus_df:
    """
    Build the review document-frequency class
    df is a dictionay of {word: frequency}
    """
    def __init__(self):
        self.df = Counter()
        self.idf = Counter()
        self.N = 0
        
    def fit(self, review_list):
        """
        Construct the df Counter based on review_list
        """
        for review in review_list:
            current_df = Counter(review.word_dict.keys())
            util.increment(self.df, 1, current_df)
        
        #inverse_df: log(N/n[word])
        self.N = len(review_list)
        self.idf = self.df.copy()
        for word in self.idf:
            self.idf[word] = log(float(self.N)/self.idf[word])

        
        
    
    


def folder_list(path,label):
    '''
    PARAMETER PATH IS THE PATH OF YOUR LOCAL FOLDER
    return a tuple: (review word list, review label)
    '''
    filelist = os.listdir(path)
    review_list = []
    for infile in filelist:
        file = os.path.join(path,infile)

        r = review_instance()
        r.read_file(file)
        r.set_label(label)

        review_list.append(r)
    return review_list


def shuffle_data():
    '''
    pos_path is where you save positive review data.
    neg_path is where you save negative review data.
    '''
    pos_path = "/Users/how/Dropbox/Python Script/hw3/data/pos"
    neg_path = '/Users/how/Dropbox/Python Script/hw3/data/neg'

    pos_review = folder_list(pos_path,1)
    neg_review = folder_list(neg_path,-1)

    review_list = pos_review + neg_review
    np.random.seed(seed=8)
    np.random.shuffle(review_list)
    return review_list





