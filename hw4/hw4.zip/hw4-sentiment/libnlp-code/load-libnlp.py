from libnlp import *
import glob

# Set up the libnlp engine
eng = core.Engine()
algo.initDefault(eng)

# name where the model will go
modelFileName = 'model.dat'

# tell the engine we want IDF 
eng.setParameter('libnlp::algo::TokenFeatureExtractor','Features','idf')
eng.setParameter('libnlp::algo::DocumentFeatureMapper','ComputeFrequency',True)
eng.setParameter('libnlp::algo::DocumentFeatureVectorizer','UpdateIndex',True)
eng.setParameter('libnlp::algo::IdfTagger<libnlp::attr::TokenContent>','ModelFile',modelFileName)
eng.setParameter('libnlp::algo::IdfTagger<libnlp::attr::TokenContent>','UseSmoothing', True)

# load the data
corpus = attr.Corpus()

files = glob.glob("data/*/*.txt")    
for file in files:
    # print(file)
    with open(file) as f:
        d = core.Document(f.read())
        d.put(attr.Language('en'), 'user')
        corpus.append(d)

# tell libnlp what we want to process        
coll = core.Document()
coll.put(corpus, 'user')

# generate the model
model = eng.gen(coll, attr.IdfModel)


model.save(modelFileName)

# now compute values for a new document
doc = core.Document('I hated the persimonney movie.')

# and print them out
for feat in eng.gen(doc, attr.TokenFeatureMapList):
    print('{0}: {1}'.format(doc.contentAt(feat), feat))

# below here are some other features you might like

# ** DICTIONARIES**

# load positive and negative sentiment dictionaries (you can get them from the web)
eng = core.Engine()
algo.initDefault(eng)

doc = core.Document('I hated the persimonney movie.')

bloom_dir=('dicts')
eng.setParameter('libnlp::algo::BloomFilter', 'dirOrFileName', bloom_dir)

# get the features from this dictionary-based approach for our test document
foundToks = eng.gen(doc, attr.MatchList)
for pt in foundToks:
    print doc.contentAt(pt), pt

# ** OTHER LIGHTWEIGHT LEXICAL FEATURES**
eng = core.Engine()
algo.initDefault(eng)

eng.setParameter('libnlp::algo::TokenFeatureExtractor','Features','w stem shp lem')

doc = core.Document('I hated the persimonney movie.')

feats = eng.gen(doc, attr.TokenFeatureMapList)
for feat in eng.gen(doc, attr.TokenFeatureMapList):
    print('{0}: {1}'.format(doc.contentAt(feat), feat))
